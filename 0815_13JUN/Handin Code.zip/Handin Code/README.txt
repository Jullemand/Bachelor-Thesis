Here is the order to run the scripts

#### DATA COLLECTION

1. HANDIN_ebay_scraper.py
2. 1_Investigate Data.ipynb
3. 2_Prepare for ANN.ipynb


#### ANALYSIS

## Hermite Series Estimation

1. HANDIN_Normal Density Estimation.R
2. HANDIN_Hermite Estimation.R

## Artificial Neural Network (ANN)

1. HANDIN_Divide_into_classes.py
2. HANDIN_ANN.py



